function calcular(){
var val1 = document.getElementById ('val1').value;
var val2 = document.getElementById ('val2').value;
var val3 = document.getElementById ('val3').value;
var val4 = document.getElementById ('val4').value;
var result = (parseInt(val1) + parseInt(val2) + parseInt(val3) + parseInt(val4)) /4;
alert (result);
}


function clean() {

    document.getElementById("val1").value = ("");
    document.getElementById("val2").value = ("");
    document.getElementById("val3").value = ("");
    document.getElementById("val4").value = ("");
}